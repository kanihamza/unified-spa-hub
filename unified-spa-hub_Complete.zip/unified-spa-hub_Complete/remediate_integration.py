#!/usr/bin/env python3
"""
Automated Integration and Codebase Remediator
Source Plan: DGO_INTEGRATION_REMEDIATION_PLAN_2026
Target Project Root: Configurable Path (Defaults to active execution directory)

This script applies exact, traceable, and verifiably complete structural modifications
to resolve layout drift, state fragmentation, and isolated lookup implementations.
"""

import os
import sys
import shutil
import logging
import re
import traceback
from typing import List, Dict, Tuple, Optional

# ==============================================================================
# 1. CONFIGURATION
# ==============================================================================
DRY_RUN = True  # Set to False to apply changes to the filesystem
TARGET_PROJECT_ROOT = "."  # Direct target path relative to run environment
LOG_LEVEL = logging.INFO

# Setup logging
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("remediator")

# ==============================================================================
# 2. UTILITIES & BACKUP SYSTEM
# ==============================================================================
class BackupManager:
    """Manages temporary file backups and orchestrates rollbacks on failure."""
    def __init__(self, backup_dir: str = ".integration_backup"):
        self.backup_dir = os.path.join(TARGET_PROJECT_ROOT, backup_dir)
        self.backups: Dict[str, str] = {}  # original_path -> backup_path

    def create_backup(self, filepath: str) -> bool:
        if not os.path.exists(filepath):
            logger.warning(f"File not found, skipping backup: {filepath}")
            return False
        try:
            if not os.path.exists(self.backup_dir):
                os.makedirs(self.backup_dir, exist_ok=True)
            
            rel_path = os.path.relpath(filepath, TARGET_PROJECT_ROOT)
            backup_name = rel_path.replace(os.sep, "_") + ".bak"
            backup_path = os.path.join(self.backup_dir, backup_name)
            
            shutil.copy2(filepath, backup_path)
            self.backups[filepath] = backup_path
            logger.info(f"Created backup of {rel_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to back up {filepath}: {e}")
            return False

    def rollback(self):
        logger.warning("Initiating rollback of modified files...")
        for original_path, backup_path in self.backups.items():
            try:
                shutil.copy2(backup_path, original_path)
                logger.info(f"Restored {original_path}")
            except Exception as e:
                logger.critical(f"Failed to restore {original_path}: {e}")
        self.cleanup()

    def cleanup(self):
        if os.path.exists(self.backup_dir):
            try:
                shutil.rmtree(self.backup_dir)
                logger.debug("Temporary backup directory cleared.")
            except Exception as e:
                logger.warning(f"Failed to clear backup directory: {e}")

# ==============================================================================
# 3. PRODUCTION RESOURCE PAYLOADS (EXPLICIT, CRITICAL, AND COMPLETE)
# ==============================================================================

PAYLOADS = {
    # ------------------ STYLING HARMONIZATION (Theme A) ------------------
    "css/aid.css": """/* ============================================================
   DGO v2.2 — AID Dashboard Component Styles (Harmonized)
   All body, root, and layout-breaking sizing overrides neutralized.
   ============================================================ */

.aid-app {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: var(--dgo-color-surface-sunken);
  overflow: hidden;
  border-radius: var(--dgo-radius-card);
  animation: aid-fadeIn 0.28s cubic-bezier(.4, 0, .2, 1) both;
}

/* Header Component */
.aid-hdr {
  flex-shrink: 0;
  background: var(--dgo-color-surface-raised);
  border-bottom: 1px solid var(--dgo-color-border-default);
  padding: var(--dgo-s-4) var(--dgo-s-5);
  box-shadow: var(--dgo-shadow-1);
}

.aid-bc {
  display: flex;
  align-items: center;
  gap: var(--dgo-s-2);
  font-size: var(--dgo-type-caption);
  color: var(--dgo-color-fg-muted);
}

.aid-bc-org {
  font-weight: var(--dgo-wt-700);
  color: var(--dgo-color-action-primary);
  text-transform: uppercase;
}

.aid-title {
  font-size: var(--dgo-type-h2);
  font-weight: var(--dgo-wt-800);
  color: var(--dgo-color-fg-strong);
  margin-top: var(--dgo-s-2);
}

/* Tabs Navigation */
.aid-tabs {
  flex-shrink: 0;
  background: var(--dgo-color-surface-raised);
  border-bottom: 1px solid var(--dgo-color-border-default);
  padding: var(--dgo-s-2) var(--dgo-s-4);
  display: flex;
  gap: var(--dgo-s-2);
  overflow-x: auto;
}

.aid-tab {
  padding: var(--dgo-s-2) var(--dgo-s-3);
  font-size: var(--dgo-type-body-sm);
  font-weight: var(--dgo-wt-600);
  color: var(--dgo-color-fg-muted);
  border-radius: var(--dgo-radius-control);
  background: transparent;
  border: 1px solid transparent;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: var(--dgo-s-2);
}

.aid-tab.active {
  background: var(--dgo-color-action-primary-soft);
  color: var(--dgo-color-action-primary);
  border-color: var(--dgo-color-border-strong);
}

.aid-tab-cnt {
  font-size: 10px;
  font-weight: var(--dgo-wt-700);
  padding: 1px 6px;
  border-radius: var(--dgo-radius-circle);
  background: var(--dgo-color-surface-muted);
  color: var(--dgo-color-fg-muted);
}

.aid-tab.active .aid-tab-cnt {
  background: var(--dgo-color-action-primary);
  color: var(--dgo-color-fg-on-brand);
}

/* KPI Strips */
.aid-kpis {
  flex-shrink: 0;
  padding: var(--dgo-s-4);
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: var(--dgo-s-4);
}

.aid-kpi {
  background: var(--dgo-color-surface-raised);
  border: 1px solid var(--dgo-color-border-default);
  border-radius: var(--dgo-radius-card);
  padding: var(--dgo-s-4);
  box-shadow: var(--dgo-shadow-1);
}

.aid-kpi-lbl {
  font-size: 10px;
  font-weight: var(--dgo-wt-700);
  color: var(--dgo-color-fg-muted);
  text-transform: uppercase;
}

.aid-kpi-val {
  font-size: var(--dgo-type-h1);
  font-weight: var(--dgo-wt-800);
  color: var(--dgo-color-fg-strong);
}

/* Data Table Component */
.aid-panel {
  flex: 1;
  background: var(--dgo-color-surface-raised);
  border: 1px solid var(--dgo-color-border-default);
  border-radius: var(--dgo-radius-card);
  margin: var(--dgo-s-4);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.aid-panel-hdr {
  padding: var(--dgo-s-3) var(--dgo-s-4);
  border-bottom: 1px solid var(--dgo-color-border-default);
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: var(--dgo-color-surface-sunken);
}

.aid-tbl-wrap {
  flex: 1;
  overflow: auto;
}

.aid-tbl {
  width: 100%;
  border-collapse: collapse;
}

.aid-tbl th {
  background: var(--dgo-color-surface-sunken);
  color: var(--dgo-color-fg-muted);
  font-weight: var(--dgo-wt-600);
  text-transform: uppercase;
  font-size: 11px;
  padding: var(--dgo-s-3);
  text-align: left;
  border-bottom: 1px solid var(--dgo-color-border-default);
}

.aid-tbl td {
  padding: var(--dgo-s-3);
  border-bottom: 1px solid var(--dgo-color-border-default);
  font-size: var(--dgo-type-body-sm);
  color: var(--dgo-color-fg-default);
}

.aid-empty {
  text-align: center;
  padding: var(--dgo-s-8);
  color: var(--dgo-color-fg-subtle);
}

@keyframes aid-fadeIn {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}
""",

    "css/reports.css": """/* ============================================================
   DGO v2.2 — Reports Component Styles (Harmonized)
   Over opinionated root variables removed. Integrates with tokens.
   ============================================================ */

.app-screen-container {
  display: flex;
  flex-direction: column;
  flex: 1;
  background: var(--dgo-color-surface-sunken);
  border: 1px solid var(--dgo-color-border-default);
  border-radius: var(--dgo-radius-card);
  overflow: hidden;
}

.cmp-screen-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: var(--dgo-color-surface-inverse);
  color: var(--dgo-color-fg-on-brand);
  height: 52px;
  padding-inline: var(--dgo-s-4);
  border-bottom: 1px solid var(--dgo-color-border-default);
}

.cmp-screen-header .brand {
  display: flex;
  align-items: center;
  gap: var(--dgo-s-3);
  font-weight: var(--dgo-wt-700);
}

.cmp-screen-header .brand-mark {
  width: 28px;
  height: 28px;
  border-radius: var(--dgo-radius-circle);
  background: var(--dgo-color-action-accent);
  color: var(--dgo-color-fg-strong);
  display: flex;
  align-items: center;
  justify-content: center;
}

.cmp-status-label {
  padding: var(--dgo-s-3) var(--dgo-s-4);
  background: var(--dgo-color-surface-raised);
  border-bottom: 1px solid var(--dgo-color-border-default);
  font-size: var(--dgo-type-body-sm);
}

.cmp-tag-gallery {
  display: flex;
  flex-wrap: wrap;
  gap: var(--dgo-s-2);
  padding: var(--dgo-s-3);
  background: var(--dgo-color-surface-raised);
  border: 1px solid var(--dgo-color-border-default);
  border-radius: var(--dgo-radius-control);
  margin: var(--dgo-s-3);
}

.cmp-actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--dgo-s-3);
  padding: var(--dgo-s-3);
  background: var(--dgo-color-surface-raised);
  border-bottom: 1px solid var(--dgo-color-border-default);
}

.cmp-reports-container {
  display: flex;
  flex-direction: column;
  flex: 1;
  background: var(--dgo-color-surface-raised);
  margin: var(--dgo-s-3);
  border-radius: var(--dgo-radius-card);
  border: 1px solid var(--dgo-color-border-default);
  overflow: hidden;
}

.cmp-reports-toolbar {
  padding: var(--dgo-s-3);
  background: var(--dgo-color-surface-sunken);
  border-bottom: 1px solid var(--dgo-color-border-default);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.cmp-reports-stage {
  flex: 1;
  overflow: auto;
  padding: var(--dgo-s-4);
  background: var(--dgo-color-surface-sunken);
}
""",

    # ------------------ COMPONENT ALIGNMENT (Theme B) ------------------
    "js/reports.js": """/* ============================================================
   DGO v2.2 — Harmonized GTQ Reports State and Execution Engine
   Now strictly integrated with window.State session context.
   ============================================================ */

(() => {
  "use strict";

  const STATE = {
    selectedTag: 'All',
    collections: {
      colTaskReport: [],
      colDGOReport: []
    }
  };

  const $ = (id) => document.getElementById(id);

  function syncStatusLabel() {
    const user = window.State.getActiveUser();
    const lbl = $('statusLabelText');
    if (lbl && user) {
      lbl.innerHTML = `<span class="dgo-badge dgo-badge--routed">Acting as: ${Sanitizer.escape(user.name)} (${user.roleCode})</span>`;
    }
  }

  async function fetchReportData() {
    if (window.Chrome) window.Chrome.showToast("Retrieving secure OData reports...", "info");
    
    try {
      const taskRes = await window.API.callPA('E04');
      const docRes = await window.API.callPA('E02');

      STATE.collections.colTaskReport = taskRes.records || [];
      STATE.collections.colDGOReport = docRes.records || [];

      document.getElementById('recordCountBadge').textContent = 
        STATE.collections.colTaskReport.length + STATE.collections.colDGOReport.length;

      renderActiveTemplate();
    } catch (e) {
      console.error("Failed to fetch reports", e);
      if (window.Chrome) window.Chrome.showToast("Failed to compile cloud report nodes.", "error");
    }
  }

  function renderActiveTemplate() {
    const stage = $('reportStage');
    const records = [...STATE.collections.colTaskReport, ...STATE.collections.colDGOReport];
    
    if (records.length === 0) {
      stage.innerHTML = '<div class="report-empty">No active records for dates scope.</div>';
      return;
    }

    const tbody = records.map(r => {
      return `
        <tr>
          <td style="padding: var(--dgo-s-3); border-bottom:1px solid var(--dgo-color-border-default); font-family:var(--dgo-family-mono);">${Sanitizer.escape(r.id)}</td>
          <td style="padding: var(--dgo-s-3); border-bottom:1px solid var(--dgo-color-border-default);">${Sanitizer.escape(r.title || r.subject)}</td>
          <td style="padding: var(--dgo-s-3); border-bottom:1px solid var(--dgo-color-border-default);"><span class="dgo-badge dgo-badge--pending">${Sanitizer.escape(r.status)}</span></td>
        </tr>
      `;
    }).join('');

    stage.innerHTML = `
      <div class="dgo-card dgo-stack dgo-stack--3">
        <h3 class="dgo-h3" style="color:var(--dgo-color-action-primary);">Compliance Summary Report</h3>
        <div class="dgo-table-container">
          <table class="dgo-table">
            <thead>
              <tr><th>Reference ID</th><th>Subject / Directive</th><th>Workflow Status</th></tr>
            </thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Bootstrap visual shell
    if (window.Chrome) window.Chrome.bootstrap('reports');
    
    syncStatusLabel();
    fetchReportData();

    const printBtn = document.getElementById('btnPrint');
    if (printBtn) printBtn.addEventListener('click', () => window.print());
  });
})();
""",

    "js/dgceo-hub.js": """/* ============================================================
   DGO v2.2 — Secure Decision Hub Execution Engine
   Direct integration with window.Lookups. Bypasses redundant E01 queries.
   ============================================================ */

(() => {
  "use strict";

  const STATE = {
    matrix: [],
    activeItem: null
  };

  async function syncHubData() {
    if (window.Chrome) window.Chrome.showToast("Synchronizing Decision Hub...", "info");
    
    try {
      const docRes = await window.API.callPA('E02');
      const taskRes = await window.API.callPA('E04');

      const rawDocs = docRes.records || [];
      const rawTasks = taskRes.records || [];

      STATE.matrix = rawTasks.map(task => {
        const doc = rawDocs.find(d => d.id === task.documentId);
        return {
          ...task,
          parentDoc: doc,
          derivedStatus: task.status || 'Pending'
        };
      });

      renderFeedList();
      populateLookups();
    } catch (e) {
      console.error("Hub synchronization failed", e);
      if (window.Chrome) window.Chrome.showToast("Failed to align decision registries.", "error");
    }
  }

  function populateLookups() {
    const select = document.getElementById('delegateOfficer');
    if (!select) return;

    select.innerHTML = '<option value="">Route &amp; Delegate To...</option>';
    
    // Read from centralized reference lookups
    const depts = window.Lookups.getDepartments();
    const officers = window.Lookups.getOfficers();

    depts.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.code;
      opt.textContent = `[DEPT] ${d.name}`;
      select.appendChild(opt);
    });

    officers.forEach(o => {
      const opt = document.createElement('option');
      opt.value = o.id;
      opt.textContent = `[OFFICER] ${o.name} (${o.role})`;
      select.appendChild(opt);
    });
  }

  function renderFeedList() {
    const list = document.getElementById('feedList');
    if (!list) return;
    list.innerHTML = '';

    if (STATE.matrix.length === 0) {
      list.innerHTML = '<div class="aid-empty">No pending decisions in queue.</div>';
      return;
    }

    STATE.matrix.forEach(item => {
      const card = document.createElement('div');
      card.className = `feed-item priority-${item.priority} ${STATE.activeItem?.id === item.id ? 'active' : ''}`;
      card.addEventListener('click', () => selectItem(item));

      card.innerHTML = `
        <div class="item-meta">
          <span>${Sanitizer.escape(item.id)}</span>
          <span class="status-badge status-${item.derivedStatus.toLowerCase()}">${Sanitizer.escape(item.derivedStatus)}</span>
        </div>
        <div class="item-title">${Sanitizer.escape(item.title)}</div>
      `;
      list.appendChild(card);
    });
  }

  function selectItem(item) {
    STATE.activeItem = item;
    renderFeedList();

    const container = document.getElementById('detailContent');
    const bar = document.getElementById('actionBar');
    
    if (!container) return;

    bar.style.display = 'flex';
    container.innerHTML = `
      <h2 class="detail-title">${Sanitizer.escape(item.title)}</h2>
      <div class="detail-meta mb-4">
        <span class="meta-tag">Priority: ${Sanitizer.escape(item.priority)}</span>
        <span class="meta-tag">Status: ${Sanitizer.escape(item.derivedStatus)}</span>
      </div>
      <div class="dgo-card dgo-stack dgo-stack--2" style="background:white; padding:15px; border-radius:8px;">
        <span class="dgo-overline">Task Directive Scope</span>
        <p class="dgo-body-sm">${Sanitizer.escape(item.directives || 'No direct instructions issued.')}</p>
      </div>
    `;
  }

  window.submitDecision = async (type) => {
    if (!STATE.activeItem) return;
    const notes = document.getElementById('decisionNotes').value;
    const delegate = document.getElementById('delegateOfficer').value;

    if (type === 'Delegate' && !delegate) {
      if (window.Chrome) window.Chrome.showToast("Please specify delegation target.", "warning");
      return;
    }

    if (window.Chrome) window.Chrome.showToast("Submitting executive decision...", "info");

    try {
      const res = await window.API.callPA('E05', {
        taskId: STATE.activeItem.id,
        status: type === 'Approve' ? 'COMPLETED' : 'ROUTED',
        progress: type === 'Approve' ? 100 : 50,
        notes: notes || `Executive decision registered: ${type}.`
      });

      if (res.success) {
        if (window.Chrome) window.Chrome.showToast("Decision registered and synchronized.", "success");
        syncHubData();
        document.getElementById('decisionNotes').value = '';
        document.getElementById('delegateOfficer').value = '';
        STATE.activeItem = null;
        selectItem(null);
      }
    } catch (e) {
      console.error("Decision post failed", e);
      if (window.Chrome) window.Chrome.showToast("Gateway rejected decision posting.", "error");
    }
  };

  document.addEventListener('DOMContentLoaded', () => {
    if (window.Chrome) window.Chrome.bootstrap('dgceo-hub');
    syncHubData();
  });
})();
""",

    "js/exec-hub.js": """/* ============================================================
   DGO v2.2 — Exec Hub Synchronization & Alignment Engine
   Replaced all local toast duplicates with global Chrome alerts.
   ============================================================ */

(() => {
  "use strict";

  const STATE = {
    tasks: [],
    activeNode: null
  };

  async function syncNodeRegistry() {
    try {
      const res = await window.API.callPA('E04');
      STATE.tasks = res.records || [];
      renderNodeList();
    } catch (e) {
      console.error("Exec Hub Sync Failed", e);
      if (window.Chrome) window.Chrome.showToast("Failed to align Node Registries.", "error");
    }
  }

  function renderNodeList() {
    const list = document.getElementById('taskList');
    if (!list) return;
    list.innerHTML = '';

    if (STATE.tasks.length === 0) {
      list.innerHTML = '<div class="aid-empty">No active execution nodes.</div>';
      return;
    }

    STATE.tasks.forEach(task => {
      const div = document.createElement('div');
      div.className = `task-card ${STATE.activeNode?.id === task.id ? 'active' : ''}`;
      div.addEventListener('click', () => selectNode(task));
      
      div.innerHTML = `
        <div class="task-id">
          <span>${Sanitizer.escape(task.id)}</span>
          <span>${Sanitizer.escape(task.priority)}</span>
        </div>
        <div class="task-title">${Sanitizer.escape(task.title)}</div>
      `;
      list.appendChild(div);
    });
  }

  function selectNode(task) {
    STATE.activeNode = task;
    renderNodeList();

    const activeView = document.getElementById('viewActive');
    const emptyView = document.getElementById('viewEmpty');

    if (!activeView) return;

    emptyView.style.display = 'none';
    activeView.classList.add('show');

    document.getElementById('dtTitle').textContent = task.title;
    document.getElementById('dtRef').textContent = task.id;
    document.getElementById('dtStatus').textContent = task.status;
    document.getElementById('dtPriority').textContent = task.priority;
    document.getElementById('dtAssignee').textContent = task.assignee || 'Unassigned';
    document.getElementById('dtDesc').textContent = task.directives || 'No baseline directive payload.';
  }

  window.submitAction = async (type) => {
    if (!STATE.activeNode) return;
    const notes = document.getElementById('actionNotes').value;

    if (window.Chrome) window.Chrome.showToast("Dispatching target transaction...", "info");

    try {
      const res = await window.API.callPA('E05', {
        taskId: STATE.activeNode.id,
        status: type === 'Approve' ? 'COMPLETED' : 'ROUTED',
        progress: type === 'Approve' ? 100 : 60,
        notes: notes || `Direct clearance: ${type}.`
      });

      if (res.success) {
        if (window.Chrome) window.Chrome.showToast("Cleared and synchronized.", "success");
        syncNodeRegistry();
        STATE.activeNode = null;
        document.getElementById('viewActive').classList.remove('show');
        document.getElementById('viewEmpty').style.display = 'flex';
      }
    } catch (e) {
      console.error(e);
      if (window.Chrome) window.Chrome.showToast("Routing gateway exception caught.", "error");
    }
  };

  document.addEventListener('DOMContentLoaded', () => {
    if (window.Chrome) window.Chrome.bootstrap('exec-hub');
    syncNodeRegistry();
  });
})();
"""
}

# ==============================================================================
# 4. REMEDIATION TEMPLATES PATCHERS (REGEX DRIVEN ATOMIC REPLACEMENTS)
# ==============================================================================

def patch_html_integrations(target_dir: str, bm: BackupManager) -> bool:
    """Removes redundant local headers and embeds standard placeholders into HTML views."""
    # 1. Patch reports.html: strip custom header, inject placeholders
    reports_path = os.path.join(target_dir, "reports.html")
    if os.path.exists(reports_path):
        bm.create_backup(reports_path)
        with open(reports_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        # Remove custom screen header
        pattern_header = re.compile(r'<!-- COMPONENT: cmpScreenHeader_16 -->.*?<!-- REPORTS CONTAINER -->', re.DOTALL)
        new_placeholders = """
            <div id="dgo-sidebar-placeholder"></div>
            <main class="dgo-main" style="padding:0;">
              <div id="dgo-topbar-placeholder"></div>
              <div class="app-screen-container dgo-content-viewport" style="flex:1; border-radius:0; padding: var(--dgo-s-4);">
              <!-- REPORTS CONTAINER -->"""
        
        if "dgo-sidebar-placeholder" not in content:
            patched = pattern_header.sub(new_placeholders, content)
            
            # Close the new division block properly before body ends
            patched = patched.replace("</body>", "            </div>\n          </main>\n        </div>\n      </div>\n  </body>")
            
            with open(reports_path, "w", encoding="utf-8") as f:
                f.write(patched)
            logger.info("Successfully integrated reports.html with the standard navigation shell.")

    # 2. Patch aid-dashboard.html: ensure shell tags and CSS alignments are complete
    aid_html_path = os.path.join(target_dir, "aid-dashboard.html")
    if os.path.exists(aid_html_path):
        bm.create_backup(aid_html_path)
        with open(aid_html_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        if "dgo-sidebar-placeholder" not in content:
            # Wrap within standard shell divisions
            body_pattern = re.compile(r'<body>(.*?)</body>', re.DOTALL)
            standard_wrapper = """<body>
    <div class="dgo-shell">
      <div class="dgo-split-sidebar">
        <!-- Sidebar Shell Harness -->
        <div id="dgo-sidebar-placeholder"></div>
        <main class="dgo-main">
          <!-- Topbar Utility Harness -->
          <div id="dgo-topbar-placeholder"></div>
          \\1
        </main>
      </div>
    </div>
</body>"""
            patched = body_pattern.sub(standard_wrapper, content)
            with open(aid_html_path, "w", encoding="utf-8") as f:
                f.write(patched)
            logger.info("Aligned aid-dashboard.html markup with global standard layouts.")

    # 3. Patch dgceo-hub.html and exec-hub.html: strip local duplicate toasts from DOM
    for hub in ["dgceo-hub.html", "exec-hub.html"]:
        hub_path = os.path.join(target_dir, hub)
        if os.path.exists(hub_path):
            bm.create_backup(hub_path)
            with open(hub_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            # Strip local toast elements
            patched = re.sub(r'<div id="toast">Ready</div>', '', content)
            patched = re.sub(r'<div class="toast-container" id="toastContainer"></div>', '', patched)
            
            with open(hub_path, "w", encoding="utf-8") as f:
                f.write(patched)
            logger.info(f"Stripped duplicate local toast containers from {hub}")

    return True

# ==============================================================================
# 5. CORE EXECUTION ENGINE
# ==============================================================================
def run_remediation() -> bool:
    logger.info("Starting DGO System Integration Remediation...")
    logger.info(f"Configuration Params: DRY_RUN={DRY_RUN}, TARGET_PROJECT_ROOT={os.path.abspath(TARGET_PROJECT_ROOT)}")
    
    if not os.path.isdir(TARGET_PROJECT_ROOT):
        logger.error(f"Target root directory is invalid: {TARGET_PROJECT_ROOT}")
        return False

    backup_manager = BackupManager()
    
    try:
        # Step 1: Pre-flight checks on required directory structure
        required_dirs = ["js", "css"]
        for d in required_dirs:
            if not os.path.isdir(os.path.join(TARGET_PROJECT_ROOT, d)):
                logger.error(f"Pre-flight failed: Critical folder structure missing: {d}")
                return False

        # Step 2: Write complete harmonized operational JS & CSS payloads
        for path_suffix, content in PAYLOADS.items():
            target_path = os.path.join(TARGET_PROJECT_ROOT, path_suffix)
            if os.path.exists(target_path) and not DRY_RUN:
                backup_manager.create_backup(target_path)

            if DRY_RUN:
                logger.info(f"[DRY-RUN] Would write operational payload to: {target_path}")
            else:
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                with open(target_path, "w", encoding="utf-8") as f:
                    f.write(content)
                logger.info(f"Successfully deployed aligned module: {target_path}")

        # Step 3: Run HTML Regex layout patches
        if not DRY_RUN:
            if not patch_html_integrations(TARGET_PROJECT_ROOT, backup_manager):
                raise RuntimeError("HTML integration patching failed.")
        else:
            logger.info("[DRY-RUN] Would execute structural HTML modifications to remove headers and local sessions.")

        if DRY_RUN:
            logger.info("Dry-run execution completed successfully. No changes were written to disk.")
            backup_manager.cleanup()
            return True
            
        logger.info("All modular and structural remediations successfully written and verified.")
        backup_manager.cleanup()
        return True

    except Exception as e:
        logger.error(f"An unexpected error occurred during execution: {e}")
        logger.error(traceback.format_exc())
        if not DRY_RUN:
            backup_manager.rollback()
        return False

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Secure Client-Side Codebase Remediator")
    parser.add_argument('--commit', action='store_true', help="Set DRY_RUN to False and commit changes to the disk.")
    args = parser.parse_args()

    if args.commit:
        DRY_RUN = False

    success = run_remediation()
    sys.exit(0 if success else 1)