import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          docs: path.resolve(__dirname, 'docs.html'),
          assign: path.resolve(__dirname, 'assign.html'),
          tasks: path.resolve(__dirname, 'tasks.html'),
          emails: path.resolve(__dirname, 'emails.html'),
          response: path.resolve(__dirname, 'response-track.html'),
          responseTrack: path.resolve(__dirname, 'response-tracking.html'),
          responseMatrix: path.resolve(__dirname, 'response-matrix.html'),
          dgceoHub: path.resolve(__dirname, 'dgceo-hub.html'),
          execHub: path.resolve(__dirname, 'exec-hub.html'),
          bulk: path.resolve(__dirname, 'bulk-assign.html'),
          settings: path.resolve(__dirname, 'settings.html'),
          lookup: path.resolve(__dirname, 'lookup.html'),
          movement: path.resolve(__dirname, 'registry-movement.html'),
          ack: path.resolve(__dirname, 'ack.html'),
          aid: path.resolve(__dirname, 'aid-dashboard.html'),
          reports: path.resolve(__dirname, 'reports.html'),
        },
      },
    },
  };
});
